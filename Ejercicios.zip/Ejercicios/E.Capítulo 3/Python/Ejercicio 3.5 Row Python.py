# Databricks notebook source
# In Python
from pyspark.sql import Row
row = Row(350, True, "Learning Spark 2E", None)
# In Python
row[0]

# COMMAND ----------

row[1]


# COMMAND ----------


row[2]